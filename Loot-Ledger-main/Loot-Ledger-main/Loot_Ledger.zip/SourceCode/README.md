# Loot Ledger
The RPG Backpack Item Manager
Semesterprojekt 2024 ITP, FH Technikum Wien
